# MACIEK BRANCH

gitignore - lista elementow na ignorowanych przez git

requirements.txt - lista pakietów ( i wersji ) użytych do odpalenia plików z folderu App

App - folder z plikami które coś robią XD

App [

som_training.py - plik ktory trenuje som-a (self-organizing-map)

main.py -  interfejs fast api może sie przydać jesli bedziemy budować jakąś aplikacje, odpala sie go 
    poleceniem (bedac w folderze w ktorym znajduje sie plik) uvicorn main:app (jesli doda sie podwójna flage --reload api bedzie sie aktualizowac na bieżąco w trakcie zmian w pliku)
    najlepiej przejść do - http://127.0.0.1:8000/docs
    

]
